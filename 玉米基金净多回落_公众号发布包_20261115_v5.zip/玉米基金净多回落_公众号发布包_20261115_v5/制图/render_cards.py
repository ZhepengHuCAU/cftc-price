from __future__ import annotations

import argparse
import csv
import json
from datetime import date, timedelta
from pathlib import Path

from PIL import Image, ImageColor, ImageDraw

from card_framework import (
    DATA_GREEN, GRAY, GREEN, INK, LIGHT_GOLD, LIGHT_GREEN,
    LINE, ORANGE, CardCanvas,
)

HERE = Path(__file__).resolve().parent
LOGO = HERE / "ag-commodity-logo-transparent.png"
INPUTS = json.loads((HERE / "card_inputs.json").read_text(encoding="utf-8"))


def read_positions(filename):
    with (HERE / filename).open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    start = date.fromisoformat(INPUTS["start"])
    end = date.fromisoformat(INPUTS["end"])
    positions = []
    for row in rows:
        trading_date = date.fromisoformat(row["date"])
        if start <= trading_date <= end:
            longs = int(row["M_Money_Positions_Long_All"])
            shorts = int(row["M_Money_Positions_Short_All"])
            net = int(row["net"])
            assert longs - shorts == net
            assert trading_date == start + timedelta(days=7 * len(positions))
            positions.append((trading_date, longs, shorts, net))
    assert positions[-1][0] == end
    return positions


def label(card, x, y, value, size, fill=INK, *, bold=False, anchor="lt"):
    font = card.font(size, bold)
    card.draw.text((x, y), value, font=font, anchor=anchor, fill=fill)


def read_trend_data(corn, soy):
    with (HERE / "cftc" / "positions.csv").open(encoding="utf-8-sig", newline="") as handle:
        cftc_rows = list(csv.DictReader(handle))
    official = {}
    for code, baseline in (("002602", corn), ("005602", soy)):
        positions = [
            (date.fromisoformat(row["date"]), int(row["long"]), int(row["short"]), int(row["net"]))
            for row in cftc_rows
            if row["contract_code"] == code and row["report_variant"] == "FutOnly"
        ]
        if positions != baseline:
            raise ValueError(f"CFTC data do not match the manuscript positions for {code}.")
        official[code] = positions
    with (HERE / "weekly_futures_closes.csv").open(encoding="utf-8-sig", newline="") as handle:
        prices = list(csv.DictReader(handle))
    if [row["date"] for row in prices] != [day.isoformat() for day, *_ in corn]:
        raise ValueError("Closing prices must match the CFTC position dates.")
    return official, prices


def trend_card(out, corn, soy):
    official, prices = read_trend_data(corn, soy)
    card = CardCanvas(height=1440)
    card.header("CBOT · 持仓与期价", "玉米、大豆净持仓与期价",
                "2026年9月15日—11月3日  |  以CFTC持仓日对齐期价", LOGO)
    price_color = "#A6580C"
    card.draw.rectangle((80, 273, 114, 296), fill="#BBD7C7", outline=DATA_GREEN, width=2)
    label(card, 127, 272, "净持仓（左轴，万手）", 25, DATA_GREEN)
    card.draw.line((558, 285, 600, 285), fill=price_color, width=6)
    label(card, 615, 272, "收盘价（右轴，美分/蒲式耳）", 25, price_color)

    x0, x1 = 148, 911
    tick_dates = (0, 2, 4, 6, 7)
    xs = [x0 + i * (x1 - x0) / (len(prices) - 1) for i in range(len(prices))]
    for name, code, column, panel_top, price_ticks in (
        ("玉米", "002602", "corn_dec_2026_cents_per_bushel", 330, range(400, 561, 40)),
        ("大豆", "005602", "soy_jan_2027_cents_per_bushel", 777, range(1150, 1351, 50)),
    ):
        y0, y1 = panel_top + 80, panel_top + 359
        holdings = [row[3] / 10000 for row in official[code]]
        closes = [float(row[column]) for row in prices]
        price_min, price_max = price_ticks[0], price_ticks[-1]
        if not all(0 <= value <= 50 for value in holdings) or not all(price_min <= value <= price_max for value in closes):
            raise ValueError(f"Unexpected range for the {name} chart.")

        def holding_y(value):
            return y1 - value / 50 * (y1 - y0)

        def price_y(value):
            return y1 - (value - price_min) / (price_max - price_min) * (y1 - y0)

        label(card, 78, panel_top, name, 40, GREEN, bold=True)
        label(card, 198, panel_top + 11, f"净多 {holdings[0]:.2f} → {holdings[-1]:.2f}万手",
              27, DATA_GREEN, bold=True)
        change = f"{(closes[-1] / closes[0] - 1) * 100:+.1f}%".replace("-", "−")
        label(card, 1002, panel_top + 11, f"期价 {change}", 27, price_color, bold=True, anchor="rt")
        for i in tick_dates:
            card.draw.line((xs[i], y0, xs[i], y1), fill="#E9E2D6", width=2)
            day = official[code][i][0]
            label(card, xs[i], y1 + 19, f"{day.month}/{day.day:02d}", 25, GRAY, anchor="mt")
        for tick in range(0, 51, 10):
            y = holding_y(tick)
            card.draw.line((x0, y, x1, y), fill=LINE, width=3 if tick == 0 else 2)
            label(card, x0 - 15, y, str(tick), 25, DATA_GREEN, anchor="rm")
        for tick in price_ticks:
            y = price_y(tick)
            card.draw.line((x1, y, x1 + 8, y), fill=price_color, width=2)
            label(card, x1 + 15, y, f"{tick:,}", 25, price_color, anchor="lm")

        holding_points = [(x, holding_y(value)) for x, value in zip(xs, holdings, strict=True)]
        ink_layer = Image.new("RGBA", (x1 - x0 + 1, y1 - y0 + 1))
        local_area = [(0, y1 - y0), *((x - x0, y - y0) for x, y in holding_points),
                      (x1 - x0, y1 - y0)]
        ImageDraw.Draw(ink_layer).polygon(local_area, fill=(*ImageColor.getrgb(DATA_GREEN), 64))
        card.image.paste(ink_layer, (x0, y0), ink_layer)
        card.draw.line(holding_points, fill=DATA_GREEN, width=3, joint="curve")
        card.draw.line((x0, y0, x0, y1), fill="#548571", width=2)
        card.draw.line((x1, y0, x1, y1), fill="#B47949", width=2)
        price_points = [(x, price_y(value)) for x, value in zip(xs, closes, strict=True)]
        card.draw.line(price_points, fill=price_color, width=7, joint="curve")
        for x, y in price_points:
            card.draw.ellipse((x - 5, y - 5, x + 5, y + 5), fill=price_color)

    card.panel((78, 1210, 1002, 1327), LIGHT_GOLD)
    label(card, 102, 1228, "首末两期收盘价（美分/蒲式耳）", 24, GRAY)
    for name, column, x in (("玉米", "corn_dec_2026_cents_per_bushel", 102),
                            ("大豆", "soy_jan_2027_cents_per_bushel", 527)):
        close_first, close_last = float(prices[0][column]), float(prices[-1][column])
        label(card, x, 1270, f"{name}  {close_first:,.2f} → {close_last:,.2f}", 27, price_color, bold=True)

    label(card, 78, 1348, "来源  持仓为CFTC分类持仓（仅期货），期价为密苏里州农业部周报。", 19, GRAY)
    label(card, 78, 1378, "合约  玉米为2026年12月，大豆为2027年1月。价格取同一持仓日的收盘价。", 19, GRAY)
    return card.save(out / "01_玉米大豆净持仓与期价.png")


def group_changes(first, last):
    return first[1] - last[1], last[2] - first[2]


def decomposition_card(out, corn):
    card = CardCanvas()
    card.header("CBOT · 多空拆解", "末周净多降幅，七成来自增空", "2026年9月15日—11月3日  |  玉米管理基金  |  仅期货", LOGO)
    card.panel((78, 278, 1002, 410), LIGHT_GREEN)
    label(card, 110, 310, f"{corn[-2][3] / 10000:.2f} → {corn[-1][3] / 10000:.2f} 万手", 43, GREEN, bold=True)
    label(card, 110, 367, "最后一周的玉米净多头寸", 28, GREEN)
    for x, color, wording in ((83, DATA_GREEN, "多头减少"), (323, ORANGE, "空头增加")):
        card.draw.rounded_rectangle((x, 473, x + 27, 500), radius=5, fill=color)
        label(card, x + 41, 473, wording, 29, GRAY)

    for top, caption, start in ((550, "七周合计  ·  9月15日—11月3日", corn[0]),
                                (841, "最后一周  ·  10月27日—11月3日", corn[-2])):
        less_long, more_short = group_changes(start, corn[-1])
        total = less_long + more_short
        long_share = less_long / total
        cut = 78 + round(924 * long_share)
        label(card, 78, top, caption, 34, GREEN, bold=True)
        label(card, 78, top + 57, f"净多减少 {total / 10000:.2f}万手", 33)
        y = top + 122
        card.draw.rectangle((78, y, cut, y + 78), fill=DATA_GREEN)
        card.draw.rectangle((cut, y, 1002, y + 78), fill=ORANGE)
        label(card, (78 + cut) / 2, y + 42, f"{long_share:.0%}", 39, "white", bold=True, anchor="mm")
        label(card, (cut + 1002) / 2, y + 42, f"{1 - long_share:.0%}", 39, "white", bold=True, anchor="mm")
        label(card, 78, y + 101, f"减多 {less_long / 10000:.2f}万手", 30, DATA_GREEN)
        label(card, 1002, y + 101, f"增空 {more_short / 10000:.2f}万手", 30, ORANGE, anchor="rt")

    card.footer(["来源  CFTC Disaggregated COT（Futures Only），CBOT玉米。",
                 "口径  每条横条为各区间净多降幅的100%，按净变化分解。"], y=1266)
    return card.save(out / "02_玉米多空持仓拆解.png")


def weights_card(out):
    previous, target = INPUTS["group_weights_percent"]
    constituents = INPUTS["constituent_weights_percent"]
    assert abs(sum(row[1] for row in constituents) - previous) < 0.00001
    assert abs(sum(row[2] for row in constituents) - target) < 0.00001
    card = CardCanvas()
    card.header("彭博商品指数 · 年度调权", "谷物组目标权重创新低", "2026年→2027年  |  新权重于2027年1月展期期间生效", LOGO)
    card.panel((78, 278, 1002, 446), LIGHT_GREEN)
    label(card, 109, 311, f"{previous:.2f}% → {target:.2f}%", 61, GREEN, bold=True)
    label(card, 111, 394, f"谷物组目标权重下调 {(previous - target) * 100:.1f} 个基点", 30, GREEN)
    label(card, 79, 503, "各品种目标权重调整（基点）", 34, GREEN, bold=True)

    zero, scale = 622, 10.1
    card.draw.line((zero, 568, zero, 1076), fill=LINE, width=3)
    for index, (name, prev, new) in enumerate(constituents):
        y = 600 + index * 79
        change = (new - prev) * 100
        edge = zero + change * scale
        color = DATA_GREEN if change > 0 else ORANGE
        card.draw.rectangle((min(edge, zero), y - 16, max(edge, zero), y + 16), fill=color)
        label(card, 84, y, name, 30, anchor="lm")
        label(card, edge + (15 if change > 0 else -15), y, f"{change:+.1f}", 32, color,
              bold=True, anchor="lm" if change > 0 else "rm")

    both = sum(row[1] - row[2] for row in constituents[:2]) / (previous - target)
    card.panel((78, 1112, 1002, 1229), LIGHT_GOLD)
    label(card, 106, 1148, f"玉米和大豆合计贡献谷物组净降幅的约{both:.0%}。", 31)
    card.footer(["来源  彭博商品指数2027年目标权重公告（2026年10月29日）。",
                 "口径  1个基点＝0.01个百分点，变动按未舍入的目标权重计算。"], y=1268)
    return card.save(out / "03_彭博商品指数谷物组目标权重.png")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=HERE.parent / "images")
    args = parser.parse_args()
    corn = read_positions("corn_mm_full.csv")
    soy = read_positions("soy_mm_full.csv")
    for result in (trend_card(args.output, corn, soy), decomposition_card(args.output, corn), weights_card(args.output)):
        print(result)


if __name__ == "__main__":
    main()
